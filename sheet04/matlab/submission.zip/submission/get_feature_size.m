function feature_size = get_feature_size(feature_scale)

  magnif_factor = 3;
  feature_size = 4*magnif_factor*feature_scale;
    
